
package jcarlos.conexionbd;

import java.sql.Connection;

public class Prueba {

    public static void main(String[] args) {
        
        Connection con = Conexion.getInstance();
        
    }
    
}
